const params = new URLSearchParams(window.location.search);
const algo = params.get("algo");

const title = document.getElementById("title");
title.innerText = algo.toUpperCase() + " SORT";

const complexities = {
  bubble: ["O(n)", "O(n²)", "O(n²)"],
  insertion: ["O(n)", "O(n²)", "O(n²)"],
  selection: ["O(n²)", "O(n²)", "O(n²)"],
  merge: ["O(n log n)", "O(n log n)", "O(n log n)"],
  quick: ["O(n log n)", "O(n log n)", "O(n²)"]
};

document.getElementById("best").innerText = complexities[algo][0];
document.getElementById("avg").innerText = complexities[algo][1];
document.getElementById("worst").innerText = complexities[algo][2];

let arr = [];
const barsDiv = document.getElementById("bars");
const arrayText = document.getElementById("arrayText");

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function generateArray() {
  arr = [];
  for (let i = 0; i < 20; i++) {
    arr.push(Math.floor(Math.random() * 90) + 10);
  }
  drawBars();
  arrayText.innerText = "Array: " + arr.join(", ");
}

function drawBars(colors = {}) {
  barsDiv.innerHTML = "";
  arr.forEach((val, i) => {
    const bar = document.createElement("div");
    bar.className = "bar";
    bar.style.height = val * 2 + "px";
    bar.style.background = colors[i] || "#3b82f6"; // blue
    barsDiv.appendChild(bar);
  });
}

/* ===================== SORTS ===================== */

async function bubbleSort() {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr.length - i - 1; j++) {
      drawBars({ [j]: "#facc15", [j+1]: "#facc15" });
      await sleep(120);

      if (arr[j] > arr[j+1]) {
        [arr[j], arr[j+1]] = [arr[j+1], arr[j]];
        drawBars({ [j]: "#ef4444", [j+1]: "#ef4444" });
        await sleep(120);
      }
    }
  }
}

async function insertionSort() {
  for (let i = 1; i < arr.length; i++) {
    let key = arr[i];
    let j = i - 1;

    while (j >= 0 && arr[j] > key) {
      drawBars({ [j]: "#facc15", [j+1]: "#facc15" });
      await sleep(120);

      arr[j+1] = arr[j];
      drawBars({ [j+1]: "#ef4444" });
      j--;
    }
    arr[j+1] = key;
  }
}

async function selectionSort() {
  for (let i = 0; i < arr.length; i++) {
    let min = i;

    for (let j = i + 1; j < arr.length; j++) {
      drawBars({ [min]: "#facc15", [j]: "#facc15" });
      await sleep(120);

      if (arr[j] < arr[min]) min = j;
    }

    if (min !== i) {
      [arr[i], arr[min]] = [arr[min], arr[i]];
      drawBars({ [i]: "#ef4444", [min]: "#ef4444" });
      await sleep(120);
    }
  }
}

async function mergeSortWrapper() {
  await mergeSort(0, arr.length - 1);
}

async function mergeSort(l, r) {
  if (l >= r) return;
  const m = Math.floor((l + r) / 2);
  await mergeSort(l, m);
  await mergeSort(m + 1, r);
  await merge(l, m, r);
}

async function merge(l, m, r) {
  let left = arr.slice(l, m + 1);
  let right = arr.slice(m + 1, r + 1);
  let i = 0, j = 0, k = l;

  while (i < left.length && j < right.length) {
    drawBars({ [k]: "#facc15" });
    await sleep(120);

    if (left[i] <= right[j]) {
      arr[k++] = left[i++];
    } else {
      arr[k++] = right[j++];
    }
  }

  while (i < left.length) arr[k++] = left[i++];
  while (j < right.length) arr[k++] = right[j++];

  drawBars();
}

async function quickSortWrapper() {
  await quickSort(0, arr.length - 1);
}

async function quickSort(low, high) {
  if (low < high) {
    let pi = await partition(low, high);
    await quickSort(low, pi - 1);
    await quickSort(pi + 1, high);
  }
}

async function partition(low, high) {
  let pivot = arr[high];
  let i = low - 1;

  for (let j = low; j < high; j++) {
    drawBars({ [j]: "#facc15", [high]: "#facc15" });
    await sleep(120);

    if (arr[j] < pivot) {
      i++;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      drawBars({ [i]: "#ef4444", [j]: "#ef4444" });
      await sleep(120);
    }
  }

  [arr[i+1], arr[high]] = [arr[high], arr[i+1]];
  return i + 1;
}

/* ===================== START ===================== */

async function startSort() {
  if (arr.length === 0) {
    alert("Generate array first");
    return;
  }

  if (algo === "bubble") await bubbleSort();
  else if (algo === "insertion") await insertionSort();
  else if (algo === "selection") await selectionSort();
  else if (algo === "merge") await mergeSortWrapper();
  else if (algo === "quick") await quickSortWrapper();

  // final green bars
  const green = {};
  for (let i = 0; i < arr.length; i++) green[i] = "#22c55e";
  drawBars(green);

  arrayText.innerText = "Sorting completed...";

  setTimeout(() => {
    arrayText.innerText = "Sorted Array: " + arr.join(", ");
  }, 5000);
}
